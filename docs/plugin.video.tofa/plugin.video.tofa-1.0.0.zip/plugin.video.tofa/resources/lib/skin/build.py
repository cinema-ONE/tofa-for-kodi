# -*- coding: utf-8 -*-
"""Orchestrates resources/lib/skin/screens.py's render functions: checks
whether the rendered .xml files under resources/skins/Main/1080i/ are
stale relative to the fragment/screen source, and rewrites only the ones
that are.

Deliberately stdlib-only (no xbmc/xbmcaddon imports at module level) so
`render_all()` can be called standalone outside Kodi entirely. Only
`ensure_rendered()`, the function kodigui.py actually calls, touches
anything Kodi-specific, and only to log a failure without taking the
window down with it.
"""
from __future__ import annotations

import hashlib
import os
import re
import struct

from . import screens, tokens

# filename (as it appears under resources/skins/Main/1080i/) -> render fn
SCREENS = {
    "script-tofa-main.xml": screens.render_main,
    "script-tofa-detail.xml": screens.render_detail,
    "script-tofa-cardoptions.xml": screens.render_cardoptions,
    "script-tofa-person.xml": screens.render_person,
    "script-tofa-playoptions.xml": screens.render_playoptions,
    "script-tofa-editions.xml": screens.render_editions,
    "script-tofa-alert.xml": screens.render_alert,
    "script-tofa-splash.xml": screens.render_splash,
    "script-tofa-profile.xml": screens.render_profile,
}

# Screens written by hand rather than assembled from fragments. They are
# SOURCES like the templates are: they live under skin/static/ with all their
# comments intact, and build.py copies them into 1080i/ through exactly the
# same treatment the generated ones get -- comments stripped, capsules
# sliced, rounded rects swapped for exact-size art.
#
# Before this, they were the only screens Kodi read straight off disk, which
# meant the player's 49 capsules and the sign-in and profile chrome could
# never be sharpened no matter what the asset pipeline learned to do. Nothing
# about how they are authored changes; only where the file lives.
STATIC_SCREENS = (
    "script-tofa-player.xml",
    "script-tofa-picker.xml",
    "script-tofa-requestseasons.xml",
    "script-tofa-signin.xml",
    "script-tofa-serverpicker.xml",
)

_PACKAGE_DIR = os.path.dirname(__file__)
_OUTPUT_DIR = os.path.normpath(
    os.path.join(_PACKAGE_DIR, "..", "..", "skins", "Main", "1080i")
)
_TEMPLATES_DIR = os.path.join(_PACKAGE_DIR, "templates")
_STATIC_DIR = os.path.join(_PACKAGE_DIR, "static")
_SOURCE_FILES = (
    os.path.join(_PACKAGE_DIR, "fragments.py"),
    os.path.join(_PACKAGE_DIR, "screens.py"),
    # tokens.py too: every geometry/colour value now flows from here into both
    # the fragments and the templates, so a token-only edit changes the output
    # without touching either -- omitting it would serve stale generated XML.
    os.path.join(_PACKAGE_DIR, "tokens.py"),
    # ...and the two data modules screens.py reads AT RENDER TIME. They are
    # outside this package, which is exactly why they were missed: home_rows
    # supplies the row-slot control ids every Home/Discover row is built
    # from, and settings_pages decides which Settings pages get a real page
    # and which get 9.7's empty scaffold.
    #
    # Caught the hard way: flipping a page's `built` flag changed nothing on
    # screen, because the hash said the output was current and render_all()
    # skipped the file. The scaffold went on painting over a finished page.
    os.path.join(_PACKAGE_DIR, "..", "home_rows.py"),
    os.path.join(_PACKAGE_DIR, "..", "settings_pages.py"),
    # ...and the other modules the renderer reads: picker rows, fox names
    # and the text widths that place the fox row's dot.
    os.path.join(_PACKAGE_DIR, "..", "settings_options.py"),
    os.path.join(_PACKAGE_DIR, "..", "foxes.py"),
    os.path.join(_PACKAGE_DIR, "..", "textmetrics.py"),
    # ...and addon.xml, because ABOUT's card bakes the add-on's NAME in from
    # there (branding.app_name). Renaming the add-on would otherwise leave
    # that card showing the old name for ever: the hash would not have moved,
    # so render_all() would skip the file.
    os.path.normpath(os.path.join(_PACKAGE_DIR, "..", "..", "..", "addon.xml")),
)
_HASH_RE = re.compile(r"hash=([0-9a-f]{12})")


def _source_hash() -> str:
    h = hashlib.sha1()
    for path in _SOURCE_FILES:
        with open(path, "rb") as f:
            h.update(f.read())
    # Template files must hash too: a template-only edit doesn't touch
    # fragments.py/screens.py, so skipping them here would leave
    # ensure_rendered() serving stale generated XML. Sorted for a
    # deterministic hash regardless of directory listing order.
    for name in sorted(os.listdir(_TEMPLATES_DIR)):
        if name.endswith(".tpl"):
            with open(os.path.join(_TEMPLATES_DIR, name), "rb") as f:
                h.update(f.read())
    # ...and the hand-written screens, for the same reason: editing one has
    # to invalidate its output.
    for name in STATIC_SCREENS:
        with open(os.path.join(_STATIC_DIR, name), "rb") as f:
            h.update(f.read())
    return h.hexdigest()[:12]


def _header(render_fn_name: str, content_hash: str) -> str:
    return (
        f"<!-- GENERATED by resources/lib/skin/screens.py:{render_fn_name}(). DO NOT HAND-EDIT.\n"
        f"     hash={content_hash}. Edit resources/lib/skin/fragments.py / screens.py / the\n"
        f"     templates/*.tpl source, the hash updates automatically next time this window opens. -->\n"
    )


def _existing_hash(output_path: str) -> str | None:
    if not os.path.exists(output_path):
        return None
    try:
        with open(output_path, "r", encoding="utf-8") as f:
            head = f.read(400)  # header is always within the first few lines
    except OSError:
        return None
    match = _HASH_RE.search(head)
    return match.group(1) if match else None


_COMMENT_RE = re.compile(r"<!--(.*?)-->", re.S)


def _check_comments(body: str, render_fn_name: str) -> None:
    """XML comments may not contain `--`. Kodi's own parser tolerates it, so
    this ships silently and only fails in a strict parser; it has slipped
    through three times now, always from an em-dash-style aside in a hand
    written comment."""
    for match in _COMMENT_RE.finditer(body):
        if "--" in match.group(1):
            line = body[: match.start()].count("\n") + 1
            raise ValueError(
                f"{render_fn_name}: XML comment at line {line} contains '--', "
                f"which is not legal inside an XML comment. Use ';' or a comma."
            )


def _strip(body: str) -> str:
    """Drop comments and blank lines from the SHIPPED xml.

    The comments are the point of this package -- every non-obvious
    coordinate carries the measurement it came from -- but they are written
    for whoever reads fragments.py/*.tpl, and Kodi parses them on every
    window open for nothing. Together they are ~17% of the rendered bytes
    (script-tofa-main.xml alone: 1000K -> 823K), and that file is parsed on
    a 4K Amlogic box that takes over three seconds to build the window.

    The source keeps every word; only the generated output slims down.
    Blank lines go too: without them a stripped comment leaves a run of
    empty lines behind, which is most of what is left to save.
    """
    body = _COMMENT_RE.sub("", body)
    return "\n".join(line for line in body.split("\n") if line.strip()) + "\n"


# One <control type="image"> whose texture is a SOLID capsule 9-patch.
# Deliberately narrow: it will not match an -outline capsule, and it refuses
# to match across a </control>, so a control containing another control is
# left alone.
_PILL_RE = re.compile(
    r'(?P<indent>[ \t]*)<control type="image"(?P<attrs>[^>]*)>'
    r'(?P<body>(?:(?!</control>).)*?)'
    r'<texture border="(?P<border>\d+)">capsule-h(?P<texh>\d+)(?P<outline>-outline)?\.png</texture>'
    r'(?P<tail>(?:(?!</control>).)*?)</control>',
    re.S,
)
_TAG_RE = re.compile(r"<(posx|posy|width|height)>(-?\d+)</(?:posx|posy|width|height)>")


def _slice_pills(body: str) -> tuple[str, dict]:
    """Rebuild solid capsule 9-patches as plain, un-sliced textures.

    A 9-patch corner is stuck at the resolution of the coordinate space:
    `border="30"` means both "cut 30 pixels from the file" and "draw that
    corner 30 units wide", so denser art needs a bigger border and a bigger
    border draws a bigger corner. On the 4K box every capsule corner is
    upscaled 2x for that reason alone.

    Doing the slicing here instead removes the coupling. A pill becomes a
    left cap, a stretched middle and a right cap; a capsule drawn square is
    just a circle and becomes ONE texture. None of the pieces carries a
    border, so each is a whole texture scaled into its own control and can be
    authored at any resolution -- see tools/gen_pill_slices.py, where a cap's
    fixed 1:2 aspect is what lets one 200x400 file serve every pill height.

    Done on the rendered output rather than in fragments.py on purpose: the
    geometry is already resolved to integers here, there are 282 call sites
    spread across eight screens, and every one of them is the same shape.
    Any control this cannot prove safe is left exactly as it was.

    Outlined capsules are handled only where they are CIRCLES. A stroke has
    to stay 2px at every size, so stroked art cannot be shared across heights
    -- but a circle's art depends on nothing except its height, so one file
    per height covers it. A stroked PILL would additionally depend on its
    width, and its seam would fall in the middle of a bright hairline instead
    of in flat colour, so those keep their 9-patch.

    Skipped, and left as 9-patches:
      * outlined pills, for the reason above.
      * anything where border*2 or the texture's own height disagrees with
        the drawn height, i.e. art being stretched to a size it was not cut
        for. Nine of those exist, all in the player.
      * anything narrower than it is tall, where there is no middle to
        stretch and the caps would overlap.
    """
    stats = {"pills": 0, "circles": 0, "exact": 0, "skipped": 0}

    def rebuild(m: re.Match) -> str:
        whole = m.group(0)
        indent, border, texh = m.group("indent"), int(m.group("border")), int(m.group("texh"))
        inner = m.group("body") + m.group("tail")
        geom = {k: int(v) for k, v in _TAG_RE.findall(m.group("body") + m.group("tail"))}
        w, h = geom.get("width"), geom.get("height")
        x, y = geom.get("posx", 0), geom.get("posy", 0)
        outline = bool(m.group("outline"))
        if w is None or h is None or border * 2 != h or texh != h or w < h:
            stats["skipped"] += 1
            return whole
        if outline and w != h:
            # A stroked pill cannot be sliced -- its rim has to stay 2px at
            # every size, and a slice seam would land in the middle of a
            # bright hairline. It gets ONE texture drawn at exactly this
            # size instead (tools/gen_exact_assets.py).
            #
            # Only if that file actually exists. Otherwise the 9-patch stays,
            # which looks exactly as it does today: a size whose art has not
            # been generated yet degrades to the old behaviour rather than to
            # a missing texture. check_xml.py is what turns it into a noticed
            # problem instead of a silent one.
            exact = exact_name(w, h)
            if not os.path.exists(os.path.join(_MEDIA_DIR, exact)):
                stats["skipped"] += 1
                return whole
        else:
            exact = None
        # Everything that is not geometry or the texture rides along on each
        # piece: colordiffuse tints it, visible gates it, animation moves it.
        extra = _TAG_RE.sub("", inner).strip()
        extra = "\n".join(line for line in extra.split("\n") if line.strip())
        pad = indent + "    "
        if extra:
            extra = "\n" + "\n".join(pad + line.strip() for line in extra.split("\n"))

        def piece(px: int, pw: int, texture: str, attrs: str = "") -> str:
            return (f"{indent}<control type=\"image\"{attrs}>\n"
                    f"{pad}<posx>{px}</posx>\n"
                    f"{pad}<posy>{y}</posy>\n"
                    f"{pad}<width>{pw}</width>\n"
                    f"{pad}<height>{h}</height>{extra}\n"
                    f"{pad}<texture>{texture}</texture>\n"
                    f"{indent}</control>")

        # A control's attributes -- in practice its id -- can only be carried
        # by an outcome that emits ONE control. The three-piece split cannot:
        # duplicating an id would give Kodi three controls answering to it and
        # getControl() returns the first, silently.
        attrs = m.group("attrs") or ""
        if exact is not None:
            stats["exact"] += 1
            return piece(x, w, exact, attrs)
        if w == h:
            # A capsule drawn square IS a circle, and a circle needs no
            # slicing at all -- one whole texture, so an id rides along
            # safely. This is what gets the player's round buttons off their
            # 9-patch and onto 2x art: pill-circle.png is 400x400 and
            # pill-circle-outline-h52.png is exactly twice the 52 units it is
            # drawn at, where the 9-patch was pinned to 1:1 by its border.
            stats["circles"] += 1
            return piece(x, w, f"pill-circle-outline-h{h}.png" if outline
                         else "pill-circle.png", attrs)
        if attrs.strip():
            stats["skipped"] += 1
            return whole
        cap = h // 2
        mid = w - 2 * cap
        # The three pieces must tile the original exactly. A rounding slip
        # here would leave a transparent hairline down a pill, which is the
        # one failure this rewrite could introduce and the one that would be
        # easiest to miss on a screenshot.
        if cap + mid + cap != w:
            raise ValueError(
                f"pill slicing does not tile: {cap}+{mid}+{cap} != {w} "
                f"(height {h}). Refusing to emit a seam.")
        stats["pills"] += 1
        return "\n".join((
            piece(x, cap, "pill-cap-left.png"),
            piece(x + cap, mid, "pill-mid.png"),
            piece(x + w - cap, cap, "pill-cap-right.png"),
        ))

    return _PILL_RE.sub(rebuild, body), stats


# ---------------------------------------------------------------- exact art --
# The families whose 9-patch art can be replaced by ONE texture drawn at
# exactly the size it is used at. Each entry says how to redraw the shape:
# the radius, whether it is stroked, and the stroke width in layout units.
#
# Exact art is the only way to get a crisp corner out of Kodi at 4K -- a
# 9-patch border is both the source slice and the drawn corner size, so it
# cannot carry more pixels (see _slice_pills). The cost is that an asset is
# pinned to one width and height, so it has to be regenerated when a layout
# number moves. tools/gen_exact_assets.py and tools/check_xml.py close that
# loop: the renderer below is the single source of truth for what is needed,
# the generator asks it, and check_xml fails in BOTH directions -- a size
# with no asset, and an asset nothing asks for any more.
_EXACT_RE = re.compile(
    r'(?P<indent>[ \t]*)<control type="image">'
    r'(?P<body>(?:(?!</control>).)*?)'
    r'<texture border="\d+">capsule-h(?P<texh>\d+)-outline\.png</texture>'
    r'(?P<tail>(?:(?!</control>).)*?)</control>',
    re.S,
)
_MEDIA_DIR = os.path.normpath(
    os.path.join(_PACKAGE_DIR, "..", "..", "skins", "Main", "media")
)

# The rounded-RECTANGLE 9-patches that an exact-size texture can replace, as
# texture stem -> (corner radius, stroke width) in layout units.
#
# CALIBRATED, not assumed. Each pair was found by rendering the existing
# 9-patch at a test size and sweeping a redrawn rounded rect against it until
# the corner silhouettes matched; gen_exact_assets.py re-runs that comparison
# and refuses to ship a shape that has drifted. Two results were not what the
# names suggest: rounded-20-outline and panel-r22-outline stroke at 1 unit,
# not 2.
#
# DELIBERATELY ABSENT from _BORDER_IS_RADIUS below, and they must stay absent:
#   white-square-rounded / white-outline-rounded -- radius 6, but the surfaces
#     that still slice them as 9-patches ask for border=2 and border=16. A
#     border that is not the radius draws a truncated arc, which is what those
#     two call sites have always drawn, so their exact-size replacements are
#     allowed to sit further from the source than the others (see
#     _EXACT_TOLERANCE).
#
# DELIBERATELY ABSENT from _EXACT_RECTS:
#   panel-shadow-r22 -- a blur, not a shape.
_EXACT_RECTS = {
    "rounded-8": (8, 0),
    "rounded-14": (14, 0),
    "rounded-14-outline": (14, 2),
    "rounded-20": (20, 0),
    "rounded-20-outline": (20, 1),
    "panel-r22": (22, 0),
    "panel-r22-outline": (22, 1),
    "tag-pill": (13, 0),
    "tag-pill-outline": (13, 2),
    "white-square-rounded": (6, 0),
    "white-outline-rounded": (6, 5),
}

# How far a redrawn shape may sit from the art it replaces, in alpha. The
# default is tight because a true rounded rect reproduces exactly; the one
# allowance below is for the border-is-not-the-radius case above, set just
# over what it measures so a real drift still trips it.
# Measured, not guessed: white-square-rounded lands 5-40 off across the ten
# sizes it is used at, and every one of the four worst is a border=2 call
# site (200x34, 52x28, 150x34). 45 sits just above that; a wrong radius
# still shows up as 50-250. white-outline-rounded needed 24 while its source
# was traced art; it measures 5 now and takes the default.
_EXACT_TOLERANCE = {"white-square-rounded": 45}
_EXACT_TOLERANCE_DEFAULT = 8

# Textures whose corner is genuinely an arc of the radius above, so a usage
# that slices them at a different border is drawing something else.
_BORDER_IS_RADIUS = frozenset(_EXACT_RECTS) - {
    "white-square-rounded", "white-outline-rounded"}
# Unlike the pill split, this is a 1:1 swap inside ONE control, so a control
# with an id is fine -- nothing gets duplicated. Eight badges in Detail and
# both modal panels were being skipped purely for carrying one.
_RECT_RE = re.compile(
    r'(?P<indent>[ \t]*)<control type="image"(?P<attrs>[^>]*)>'
    r'(?P<body>(?:(?!</control>).)*?)'
    r'<texture border="(?P<border>\d+)">(?P<tex>[a-z0-9-]+)\.png</texture>'
    r'(?P<tail>(?:(?!</control>).)*?)</control>',
    re.S,
)

#: A control carrying this marker is NEVER given exact-size art.
#:
#: THE BUG IT EXISTS TO STOP, cost an afternoon on 2026-08-10 and was not the
#: first time. Exact-size art has no `border`, so Kodi stretches the WHOLE
#: texture -- corners included -- to whatever size the control ends up. That
#: is fine for a control whose size is fixed in XML, which this pipeline
#: assumed was all of them. It is wrong for any control Python resizes after
#: load: the player's 8.4 panel is authored 287x492 and `_size_panel()` sets
#: it to 222..812 by row count, so its 20px corners were being drawn as
#: 20x9 on a two-row panel and 20x31 on a nine-row one. Unequal radii,
#: inverted above six rows, and invisible to every test that drew the shape
#: at its authored size.
#:
#: The Options dialog escaped only by luck -- its exact asset had never been
#: generated, so the substitution silently declined and left the nine-patch,
#: which resizes correctly because its corners are drawn at a fixed size.
#:
#: Mark the CONTROL, not the texture: the same texture is legitimately exact
#: elsewhere. tools/check_xml.py fails the build if a control that Python
#: resizes is missing this marker.
RESIZED_MARKER = "resized-at-runtime"

def _png_size(path: str) -> tuple[int, int] | None:
    """Width and height straight out of the PNG header. Stdlib only -- this
    module runs inside Kodi, which has no Pillow."""
    try:
        with open(path, "rb") as f:
            head = f.read(24)
    except OSError:
        return None
    if head[:8] != b"\x89PNG\r\n\x1a\n":
        return None
    return struct.unpack(">II", head[16:24])

def _rect_spec(tex: str, w, h, border: int):
    """The exact-size spec for this rounded-rect usage, or None if it does
    not qualify. Shared so collect_exact_requests() and _swap_exact_rects()
    can never disagree about what is convertible -- they did once, and the
    result was a swap pointing at a file the collector had pruned."""
    if tex not in _EXACT_RECTS:
        return None
    radius, stroke = _EXACT_RECTS[tex]
    # A corner needs room for itself at both ends of both axes, AND a
    # straight edge between them. At exactly 2*radius the shape is a stadium
    # rather than a rounded rect, the corners meet with nothing in between,
    # and a redrawn version stops matching (tag-pill at 70x26 measured 27).
    if w is None or h is None or w <= 2 * radius or h <= 2 * radius:
        return None
    # The border has to BE the radius, for every texture whose corner really
    # is an arc of that size. The player slices rounded-14.png at border 8,
    # which does not draw a 14px corner at all -- it takes the inner part of
    # the arc and renders something else entirely (the same failure as
    # shipping a 2x texture with the old border). We cannot describe that
    # with a radius, so we leave it alone.
    #
    # white-square-rounded is exempt, and is the reason this is a set rather
    # than a blanket rule: its baked arc is ~4-6px whatever border it is
    # sliced at, so its rendered corner does not depend on the border. That
    # quirk is why it is used at borders from 2 to 30 in the first place.
    if tex in _BORDER_IS_RADIUS and border != radius:
        return None
    # An OVER-SLICED usage is left alone: panel-r22.png is 46x46 and two
    # dialogs slice it at border 24, past its own half-width. Kodi clamps
    # that somehow; we cannot reproduce what it draws, so we cannot prove a
    # replacement matches, so we do not make one.
    src_size = _png_size(os.path.join(_MEDIA_DIR, tex + ".png"))
    if src_size and border * 2 > min(src_size):
        return None
    return {
        "width": w, "height": h, "radius": radius, "stroke": stroke,
        "source": tex,
        # ...sliced the way the XML slices it. panel-r22 is used at border 22
        # in one place and 24 in another, and the check has to reproduce what
        # actually ships, not what the radius implies.
        "border": border,
        "tolerance": _EXACT_TOLERANCE.get(tex, _EXACT_TOLERANCE_DEFAULT),
    }


def exact_name(width: int, height: int) -> str:
    """The file an outlined pill of this exact size wants."""
    return f"pill-outline-{width}x{height}.png"


def exact_rect_name(texture: str, width: int, height: int) -> str:
    """The file a rounded rect of this exact size wants."""
    return f"exact-{texture}-{width}x{height}.png"


def collect_exact_requests() -> dict:
    """Every exact-size asset the rendered screens need, as name -> spec.

    Computed by rendering, not read from a checked-in list, so it cannot go
    stale: change a width in tokens.py and this answer changes with it.
    Callers outside Kodi (the generator, check_xml) import this directly.
    """
    def bodies():
        for render_fn in SCREENS.values():
            yield render_fn()
        # The hand-written screens are sources too, and their capsules and
        # rounded rects need art exactly as much as the generated ones do.
        for filename in STATIC_SCREENS:
            with open(os.path.join(_STATIC_DIR, filename), "r", encoding="utf-8") as f:
                yield f.read()

    wanted: dict = {}
    for body in bodies():
        for m in _EXACT_RE.finditer(body):
            geom = {k: int(v) for k, v in _TAG_RE.findall(m.group("body") + m.group("tail"))}
            w, h, texh = geom.get("width"), geom.get("height"), int(m.group("texh"))
            if w is None or h is None or texh != h or w <= h:
                continue          # circles and odd sizes are handled elsewhere
            wanted[exact_name(w, h)] = {
                "width": w, "height": h,
                "radius": h // 2,     # a stadium: the cap is a semicircle
                "stroke": 2,          # layout units, matching the 9-patch it replaces
                "source": None,       # drawn from scratch, nothing to compare against
            }
        for m in _RECT_RE.finditer(body):
            tex = m.group("tex")
            if tex not in _EXACT_RECTS:
                continue
            geom = {k: int(v) for k, v in _TAG_RE.findall(m.group("body") + m.group("tail"))}
            w, h = geom.get("width"), geom.get("height")
            spec = _rect_spec(tex, w, h, int(m.group("border")))
            if RESIZED_MARKER in m.group(0):
                spec = None          # never wanted; see RESIZED_MARKER
            if spec is not None:
                wanted[exact_rect_name(tex, w, h)] = spec
    return wanted


def _swap_exact_rects(body: str) -> tuple[str, dict]:
    """Replace rounded-rect 9-patches with one texture drawn at that size.

    Same reasoning as _slice_pills, but a rounded rect cannot be sliced into
    three: it has corners on all four sides, so there is no axis that is
    purely flat. What it can have is its own texture per size, which is only
    affordable because every size here is known at render time.

    Which shapes qualify, and their calibrated radius and stroke, is
    _EXACT_RECTS. Deliberately left out: white-square-rounded, whose corner
    is not a clean arc and cannot be reproduced (76 usages that must stay as
    they are), and panel-shadow-r22, which is a blur.

    Fail-safe like the pills: if the exact texture is not on disk, the
    9-patch stays and the shape looks exactly as it does today.
    """
    stats = {"rects": 0, "skipped": 0}

    def rebuild(m: re.Match) -> str:
        tex = m.group("tex")
        if tex not in _EXACT_RECTS:
            return m.group(0)
        if RESIZED_MARKER in m.group(0):
            # Python changes this control's size after load; exact art cannot
            # survive that. See RESIZED_MARKER.
            stats["skipped"] += 1
            return m.group(0)
        geom = {k: int(v) for k, v in _TAG_RE.findall(m.group("body") + m.group("tail"))}
        w, h = geom.get("width"), geom.get("height")
        if _rect_spec(tex, w, h, int(m.group("border"))) is None:
            stats["skipped"] += 1
            return m.group(0)
        exact = exact_rect_name(tex, w, h)
        if not os.path.exists(os.path.join(_MEDIA_DIR, exact)):
            stats["skipped"] += 1
            return m.group(0)
        stats["rects"] += 1
        return m.group(0).replace(
            f'<texture border="{m.group("border")}">{tex}.png</texture>',
            f"<texture>{exact}</texture>")

    return _RECT_RE.sub(rebuild, body), stats


#: Containers that are allowed to keep wrapping, by (filename, control id).
#:
#: Empty, and that is the point: NOTHING in the app cycles any more. The nav
#: bar was the one exception for a day -- the d-pad grammar walked on
#: 2026-08-03 recorded its Home -> ... -> Settings -> Home wrap as deliberate
#: -- and Adrian removed it on 2026-08-06 for consistency with the Apple TV
#: and Android TV apps, neither of which wraps its top nav either. The hook
#: stays because the next such exception should be one named line, not a
#: second mechanism.
_MAY_WRAP: set[tuple[str, str]] = set()

#: Kodi container types that hold ITEMS, and so can roll over from the last
#: one back to the first.
#:
#: `grouplist` is deliberately NOT here, though it was for one render. A
#: grouplist chains sibling CONTROLS and overrides their up/down (see
#: project_kodi_grouplist_scroll_limit), so a dead <onup> on the grouplist is
#: not "the list stops" -- it is "nothing inside this region can ever move up
#: again". Detail's Cast & Crew (6250) and More Like This (6350) are
#: grouplists, and giving them a dead onup would have cut Up to the tab bar
#: from both. Their own ends are movement BETWEEN controls, which the d-pad
#: grammar already says should stop, and does.
_CONTAINER_TYPES = frozenset(("list", "panel", "fixedlist", "wraplist"))

_NAV_TAGS = ("onup", "ondown", "onleft", "onright")
_CONTROL_OPEN_RE = re.compile(r"<control\b[^>]*\bid=\"(\d+)\"[^>]*>")
_CONTROL_TOKEN_RE = re.compile(r"<control\b|</control>")


def _control_block(body: str, start: int) -> int:
    """End offset of the control whose opening tag starts at `start`."""
    depth = 0
    for match in _CONTROL_TOKEN_RE.finditer(body, start):
        depth += 1 if match.group(0) == "<control" else -1
        if depth == 0:
            return match.end()
    return len(body)


def _stop_wraps(body: str, filename: str) -> tuple[str, int]:
    """Give every container a nav target on all four axes, so none of them
    roll over from the last item back to the first.

    Kodi decides whether a container wraps INTERNALLY with
    `wrapAround = !action.HasActionsMeetingCondition()`: a missing <ondown>
    means "wrap forever". Measured on Detail's episode grid, Down off the
    last row ran 1, 5, 9, 1, 5, 9 ...; a Home shelf ran ... 17, 18, 1, 2, 3.

    Two things that look like fixes are not, and both were measured here
    rather than reasoned about:

      * Naming the container ITSELF stops the internal wrap but then
        succeeds at focusing it, and a container taking focus resets to
        item 1 -- identical on screen (1, 5, 9, 1). This was the shape of
        102 nav tags across the skin, and of Search's "abc"/"123" bug.
      * Undoing the wrap from Python cannot be invisible. Kodi's focus
        engine runs BEFORE onAction and renders in between, which is the
        visible jump-to-first-and-back Adrian reported on Detail's
        episodes. That hack is what this replaces.

    Naming an id no control has satisfies the condition, so the container
    does not wrap, and then finds nowhere to go, so focus stays put.

    Applied at BUILD time and to every screen at once because the rule is
    Kodi's, not any one screen's: 100+ hand-written stops would drift, and
    a container added tomorrow gets this for free. A real target always
    wins -- this only fills in what was absent or self-referencing.
    """
    fixed = 0
    for match in reversed(list(_CONTROL_OPEN_RE.finditer(body))):
        control_id = match.group(1)
        if (filename, control_id) in _MAY_WRAP:
            continue
        opening = match.group(0)
        type_match = re.search(r'type="([a-z]+)"', opening)
        if not type_match or type_match.group(1) not in _CONTAINER_TYPES:
            continue
        end = _control_block(body, match.start())
        block = body[match.start():end]
        # Only DIRECT children count: a nested control's own nav tags, and
        # the <itemlayout>'s, say nothing about this container's.
        nested = _CONTROL_TOKEN_RE.search(block, len(opening))
        head = block[:nested.start()] if nested else block
        indent = re.search(r"\n([ \t]*)<", head)
        indent = indent.group(1) if indent else "    "
        additions = []
        for tag in _NAV_TAGS:
            present = re.search(rf"<{tag}>\s*(.*?)\s*</{tag}>", head)
            if present is None:
                additions.append(f"{indent}<{tag}>{tokens.NAV_STOP}</{tag}>")
                fixed += 1
            elif present.group(1) == control_id:
                block = block.replace(present.group(0),
                                      f"<{tag}>{tokens.NAV_STOP}</{tag}>", 1)
                head = head.replace(present.group(0),
                                    f"<{tag}>{tokens.NAV_STOP}</{tag}>", 1)
                fixed += 1
        if additions:
            block = (block[:len(opening)] + "\n" + "\n".join(additions)
                     + block[len(opening):])
        body = body[:match.start()] + block + body[end:]
    return body, fixed


#: True unless Settings > Appearance > Reduce motion is on (settings_options).
MOTION_OK = "String.IsEmpty(Window(Home).Property(tofa_reduce_motion))"
_ANIMATION_RE = re.compile(r'<animation([^>]*)>(\w+)</animation>')


def _gate_motion(body: str) -> tuple[str, int]:
    """Make every zoom, slide and drift run only while motion is allowed.

    Fades stay (they do not move), as do instant layout animations and the
    loading spinner. A Conditional move that places something gets an instant
    twin for Reduce motion, so the screen still lands where it should."""
    count = 0

    def gate(m):
        nonlocal count
        attrs, kind = m.group(1), m.group(2)
        effect = (re.search(r'effect="(\w+)"', attrs) or [None, ""])[1]
        timed = re.search(r'time="(\d+)"', attrs)
        if effect == "fade" or not timed or timed.group(1) == "0":
            return m.group(0)
        if effect == "rotate" and "loop=" in attrs:
            return m.group(0)
        cond = re.search(r'condition="([^"]*)"', attrs)
        if cond:
            new = attrs.replace(cond.group(0), f'condition="[{cond.group(1)}] + {MOTION_OK}"')
        else:
            new = attrs + f' condition="{MOTION_OK}"'
        count += 1
        out = f"<animation{new}>{kind}</animation>"
        lift = effect == "zoom" and "HasFocus" in (cond.group(1) if cond else "")
        if (kind == "Conditional" and cond and not lift
                and "loop=" not in attrs and "pulse=" not in attrs and "pin_shake" not in attrs):
            twin = re.sub(r'\s(?:time|delay|tween|easing)="[^"]*"', "", attrs)
            twin = twin.replace(cond.group(0), f'condition="[{cond.group(1)}] + !{MOTION_OK}"')
            out += f'<animation{twin} time="0">{kind}</animation>'
        return out

    return _ANIMATION_RE.sub(gate, body), count


def _write(output_path: str, render_fn, content_hash: str) -> None:
    body = render_fn()
    _check_comments(body, render_fn.__name__)
    body, _pill_stats = _slice_pills(body)
    body, _rect_stats = _swap_exact_rects(body)
    body, _ = _stop_wraps(body, os.path.basename(output_path))
    body, _ = _gate_motion(body)
    # Header comment must follow the XML declaration line, not precede it,
    # and is added AFTER stripping so it survives -- it is the one comment
    # the output needs, since it carries the staleness hash and the
    # do-not-hand-edit warning.
    decl, _, rest = body.partition("\n")
    final = decl + "\n" + _header(render_fn.__name__, content_hash) + _strip(rest)
    with open(output_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(final)


def _copy_static(filename: str, content_hash: str) -> None:
    """Put a hand-written screen through the same mill as a generated one."""
    with open(os.path.join(_STATIC_DIR, filename), "r", encoding="utf-8") as f:
        body = f.read()
    _check_comments(body, filename)
    body, _ = _slice_pills(body)
    body, _ = _swap_exact_rects(body)
    body, _ = _stop_wraps(body, filename)
    body, _ = _gate_motion(body)
    decl, _, rest = body.partition("\n")
    header = (f"<!-- COPIED from resources/lib/skin/static/{filename} and processed.\n"
              f"     hash={content_hash}. DO NOT HAND-EDIT: edit the file under static/,\n"
              f"     which keeps every comment; this copy has them stripped and its\n"
              f"     capsules and rounded rects swapped for resolution-free art. -->\n")
    with open(os.path.join(_OUTPUT_DIR, filename), "w", encoding="utf-8", newline="\n") as f:
        f.write(decl + "\n" + header + _strip(rest))


def render_all(force: bool = False) -> list[str]:
    """Render every screen in SCREENS whose output is stale (or all of
    them if force=True). Returns the filenames actually (re)written."""
    content_hash = _source_hash()
    written = []
    for filename, render_fn in SCREENS.items():
        output_path = os.path.join(_OUTPUT_DIR, filename)
        if not force and _existing_hash(output_path) == content_hash:
            continue
        _write(output_path, render_fn, content_hash)
        written.append(filename)
    for filename in STATIC_SCREENS:
        output_path = os.path.join(_OUTPUT_DIR, filename)
        if not force and _existing_hash(output_path) == content_hash:
            continue
        _copy_static(filename, content_hash)
        written.append(filename)
    return written


def ensure_rendered() -> None:
    """Cheap staleness check + render, called from kodigui.py's
    BaseFunctions.open()/create(), the one choke point every window class
    passes through. Only logs on failure so a render problem never takes
    the window down with it."""
    try:
        render_all(force=False)
    except Exception as exc:
        try:
            from .. import log
            log.warning(f"skin.build.ensure_rendered failed: {exc!r}")
        except Exception:
            pass
