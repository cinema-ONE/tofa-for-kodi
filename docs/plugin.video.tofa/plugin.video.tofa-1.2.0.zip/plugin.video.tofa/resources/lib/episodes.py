# -*- coding: utf-8 -*-
"""How an episode's season/number is written, in one place.

WHY THIS EXISTS. One file can carry several episodes -- `S04E19E20` on disk --
and server 0.9.27 started saying so: `Episode.episode_number_end` holds the
last number covered, and is NULL for the ordinary one-episode row
(`episode_number=19, episode_number_end=20`). Before that a double episode
showed only its first number, which made the second look missing from the
library.

The number is rendered in five places (Continue Watching captions, the
player's now-playing line, the Next Up rail, the episode drawer, the
directory listing), and a range that appeared in some of them but not others
would read as a different episode depending on where you looked -- so the
formatting lives here rather than in each of them.

FORM. `S4 E19-E20`, extending this client's existing `S1 E2`: a space between
the season and the episode, no zero padding, and no letter-spacing (Kodi has
none). tofa's own surfaces write `S04E19-E20` because that is the web app's
padded style; the range is what has to agree, not the padding, and being
internally consistent beats matching a different client's spelling of the
season -- the same call already made for the player's separator.
"""
from __future__ import annotations

from typing import Any, Optional


def _as_int(value: Any) -> Optional[int]:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def number_text(episode: Any, episode_end: Any = None) -> str:
    """`19`, or `19-E20` when one file covers a range.

    The trailing `E` is part of the range, not a prefix, so a caller that has
    already written `E` gets `E19-E20` rather than `E19-20`. That is the form
    tofa uses and it is unambiguous about the second number being an episode
    rather than a part or a minute.
    """
    start = _as_int(episode)
    if start is None:
        return ""
    end = _as_int(episode_end)
    # A NULL end is the ordinary case. An end that is not AFTER the start is
    # ignored rather than trusted: a row saying 19-19 (or 19-18) describes one
    # episode, and printing the range would invent a second one.
    if end is None or end <= start:
        return str(start)
    return "{0}-E{1}".format(start, end)


def number_label(season: Any, episode: Any, episode_end: Any = None) -> str:
    """`S4 E19`, or `S4 E19-E20`. Empty when either number is missing."""
    season_num = _as_int(season)
    body = number_text(episode, episode_end)
    if season_num is None or not body:
        return ""
    return "S{0} E{1}".format(season_num, body)


def title_or_number(ep: dict) -> str:
    """An episode's own title, falling back to `Episode 19` / `Episode 19-E20`.

    The fallback carries the range too: a titleless double episode listed as
    "Episode 19" is the very thing that made the 20th look absent.
    """
    title = (ep or {}).get("title")
    if title:
        return str(title)
    body = number_text((ep or {}).get("episode_number"),
                       (ep or {}).get("episode_number_end"))
    return "Episode {0}".format(body) if body else ""

#: Whether a season holds anything you can watch. The one distinction that
#: must survive every presentation of it is "nothing here" against "a season
#: you have finished": a bare zero count reads the same for both.
#:
#: Where it is SAID moved on 2026-09-21, following the Apple TV app's update
#: that day. The sidebar row now carries a mark (see season_mark), and the
#: words themselves live in the season's header. That departs from 7.1, which
#: wants the words on the row; internal-docs/DIVERGENCES.md has why.
SEASON_IN_LIBRARY = ""          #: something is playable; say nothing
SEASON_NOT_IN_LIBRARY = "none"  #: episodes are known, no files at all
SEASON_MISSING = "missing"      #: files are recorded, none of them available
SEASON_UNLOADED = "unloaded"    #: a shell; makes NO claim either way


def season_availability(season: dict) -> str:
    """Which of the four a season is in.

    7.1, and the distinction it draws is the whole point: a season with no
    files is one you never had, while a season whose files are all
    unavailable is one the server has lost track of -- a renamed folder, an
    unmounted disk. The viewer can act on the second and not on the first,
    so they must not read the same.

    A season whose episodes have not been loaded yet is a SHELL and makes no
    claim. Saying "not in library" about episodes nobody has fetched would
    be a guess, and it would flicker to something else when they arrive.
    """
    episodes = season.get("episodes")
    if not episodes:
        return SEASON_UNLOADED
    files = [f for ep in episodes for f in (ep.get("files") or [])]
    if not files:
        return SEASON_NOT_IN_LIBRARY
    if any(f.get("available") for f in files):
        return SEASON_IN_LIBRARY
    return SEASON_MISSING


#: The season sidebar's trailing mark, which replaced the episode count on
#: 2026-09-21 to match the Apple TV app. Read off that app, one season in each
#: state: the row you have SELECTED shows a dot; otherwise a finished season
#: shows a tick, one in progress says how many are left, and one with nothing
#: in the library shows a circled plus -- which it keeps even when selected,
#: since "selected" is not news about a season you cannot play.
SEASON_MARK_NONE = ""             #: an unloaded shell: no claim, no mark
SEASON_MARK_SELECTED = "selected"
SEASON_MARK_ADD = "add"           #: nothing in the library
SEASON_MARK_MISSING = "missing"   #: recorded files, none available (ours)
SEASON_MARK_COMPLETE = "complete"
SEASON_MARK_LEFT = "left"         #: carries a count


def season_tally(season: dict, progress_map: dict) -> tuple[int, int]:
    """(playable, watched) for one season.

    Playable is an episode with an available file, and the file is the FIRST
    available one -- the same choice the episode grid and next-up make, so all
    three count the same thing. The server keeps one timeline per title rather
    than per version, so which version's record is read does not change the
    answer (measured 2026-09-20, the 7.7 check).

    `progress_map` must COVER every playable file here: a file missing from it
    counts as unwatched, which is only true if it was actually asked about.
    See progress.fetch_many on why that matters.
    """
    playable = watched = 0
    for ep in season.get("episodes") or []:
        avail = [f for f in (ep.get("files") or []) if f.get("available")]
        if not avail:
            continue
        playable += 1
        record = (progress_map or {}).get(avail[0].get("id"))
        if record and record.get("completed"):
            watched += 1
    return playable, watched


def season_mark(season: dict, progress_map: dict, *, selected: bool) -> tuple[str, int]:
    """(mark, count) for a season's sidebar row; count is only for LEFT.

    Availability outranks selection: a season you cannot play keeps its
    circled plus (or our missing mark) whether or not it is the one selected,
    and a shell says nothing at all rather than guessing.
    """
    state = season_availability(season)
    if state == SEASON_UNLOADED:
        return SEASON_MARK_NONE, 0
    if state == SEASON_NOT_IN_LIBRARY:
        return SEASON_MARK_ADD, 0
    if state == SEASON_MISSING:
        return SEASON_MARK_MISSING, 0
    if selected:
        return SEASON_MARK_SELECTED, 0
    playable, watched = season_tally(season, progress_map)
    if playable and watched >= playable:
        return SEASON_MARK_COMPLETE, 0
    return SEASON_MARK_LEFT, playable - watched



#: The profile's "Missing episodes" choice, as the web app stores it.
MISSING_EPISODES_KEY = "layout.missingEpisodes"


def show_missing(preferences: Optional[dict], effective_settings: Optional[dict]) -> bool:
    """Whether a show page lists episodes the library does not hold.

    "show" and "hide" decide outright; anything else is Automatic, which
    follows the server's answer for this show (it hides them for daily
    shows)."""
    choice = (preferences or {}).get(MISSING_EPISODES_KEY)
    if choice in ("show", "hide"):
        return choice == "show"
    return (effective_settings or {}).get("show_missing_episodes") is not False


def listed_seasons(seasons: Any, show_missing_episodes: bool, today: str) -> list:
    """The seasons and episodes a show page lists.

    Hiding missing episodes keeps any episode with files and any still to
    air (`today` is an ISO date), and the seasons holding one, as the web
    app does. Each kept season remembers its full count as `episode_total`."""
    if show_missing_episodes:
        return list(seasons or [])
    out = []
    for season in seasons or []:
        episodes = season.get("episodes") or []
        kept = [e for e in episodes
                if e.get("files") or str(e.get("air_date") or "") > today]
        if kept or str(season.get("air_date") or "") > today:
            out.append(dict(season, episodes=kept,
                            episode_total=season.get("episode_total", len(episodes))))
    return out
